#!/bin/bash

rm -f ./last_synced

SDADEVS=$(ls /dev | grep sda)
if [ -z "$SDADEVS" ]; then
	echo "/dev/sda does not exist"
	sleep 5
	exit 1
fi

SDA1MOUNT=$(cat /proc/mounts | grep sda | sed 's/\ /\n/g' | grep /media )

if [ -z "$SDA1MOUNT" ]; then
	echo "/dev/sda not mounted"
	sleep 5
	exit 2
else
	echo "first non-root partition of /dev/sda mounted at $SDA1MOUNT"
fi

if [ ! -d "$SDA1MOUNT/olis-clarity/data" ]; then
	mkdir -p $SDA1MOUNT/olis-clarity/data
	echo "making dir: $SDA1MOUNT/olis-clarity/data"
fi

if [ -z "$1" ]; then
	echo "folder\"$1\" does not exist"
	sleep 5
	exit 3
else
	echo "starting copy operation..."
	cp -ruv $1 $SDA1MOUNT/olis-clarity/
	#rsync -av /var/www/html/data/ /media/usb0/olis-clarity/data

	# make sure data finished writing to device
	echo "calling sync to ensure files written to thumbdrive..."
	sync
	echo ""
	echo "successfully synchronized clarity data to thumbdrive."
	LAST_RSYNC=$(date +%s)
	echo "$LAST_RSYNC" >> ./last_synced
	sleep 5
	exit 0
fi

sleep 5
exit 9