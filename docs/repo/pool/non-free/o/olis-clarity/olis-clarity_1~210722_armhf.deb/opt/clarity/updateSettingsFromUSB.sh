#!/bin/bash

if [ ! -d "/home/pi/.config/olis-clarity/lut" ]; then
	mkdir -p /home/pi/.config/olis-clarity/lut
	echo "making dir: /home/pi/.config/olis-clarity/lut"
fi

SDADEVS=$(ls /dev | grep sda)
if [ -z "$SDADEVS" ]; then
	echo "/dev/sda does not exist"
	sleep 5
	exit 1
fi

SDAMOUNT=$(cat /proc/mounts | grep sda | sed 's/\ /\n/g' | grep /media )

if [ -z "$SDAMOUNT" ]; then
	echo "/dev/sda not mounted"
	sleep 5
	exit 2
else
	for index in $SDAMOUNT; do
		if [ -d "$index/olis-clarity/config" ]; then
			echo "Found configuration folder on $index"
			cp -fu $index/olis-clarity/config/ic.conf /home/pi/.config/olis-clarity/ic.conf
			cp -rfu $index/olis-clarity/config/lut /home/pi/.config/olis-clarity/
			echo "Copying configuration files from thumbdrive"
			chown -R pi:pi /home/pi/.config/olis-clarity/
			sudo sync
			break
		else
			echo "Did not find configuration folder on $index"
		fi
	done
fi

sleep 5
exit 0
