#!/bin/bash


SDADEVS=$(ls /dev | grep sda)
if [ -z "$SDADEVS" ]; then
	echo "/dev/sda does not exist"
	exit 1
fi

SDA1MOUNT=$(cat /proc/mounts | grep sda | sed 's/\ /\n/g' | grep /media )

if [ -z "$SDA1MOUNT" ]; then
	echo "/dev/sda not mounted"
	exit 2
else
	echo "first non-root partition of /dev/sda mounted at $SDA1MOUNT"
fi


if [ -d "$SDA1MOUNT/olis-clarity/config" ]; then
	if [ ! -d "/home/pi/.config/olis-clarity/lut" ]; then
		mkdir -p /home/pi/.config/olis-clarity/lut
		echo "making dir: /home/pi/.config/olis-clarity/lut"
	fi
	cp -fu $SDA1MOUNT/olis-clarity/config/ic.conf /home/pi/.config/olis-clarity/ic.conf
	cp -rfu $SDA1MOUNT/olis-clarity/config/lut /home/pi/.config/olis-clarity/
	echo "copying configuration files from thumbdrive"
	chown -R pi:pi /home/pi/.config/olis-clarity/
else
	echo "$SDA1MOUNT/olis-clarity/config not found"
	exit 3
fi


exit 0

if [ -d "$SDA1MOUNT/olis-clarity/updates" ]; then
	rsync -av $SDA1MOUNT/olis-clarity/updates/ /var/www/html/updates/
	chmod -R 777 /var/www/html/updates/
fi


VERSIONSHERE=$(ls | grep clarity | sed 's/v//' | sed 's/_clarity//')

if [ -e "$SDA1MOUNT/clarity/upgrade" ]; then
	CLARITYTHERE=$(ls $SDA1MOUNT/clarity/upgrade | grep clarity)
	echo $CLARITYTHERE
else
	echo "$SDA1MOUNT/clarity/upgrade does not exist"
fi

VERSIONSTHERE=$(echo "$CLARITYTHERE" | sed 's/v//' | sed 's/_clarity//')
