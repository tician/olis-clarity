#!/bin/bash


SDADEVS=$(ls /dev | grep sda)
if [ -z "$SDADEVS" ]; then
	echo "/dev/sda does not exist"
	exit
fi

SDA1MOUNT=$(cat /proc/mounts | grep sda | sed 's/\ /\n/g' | grep /media )

if [ -z "$SDA1MOUNT" ]; then
	echo "/dev/sda not mounted"
	exit
else
	echo "first non-root partition of /dev/sda mounted at $SDA1MOUNT"
fi

if [ ! -d "$SDA1MOUNT/olis-clarity/data" ]; then
	mkdir -p $SDA1MOUNT/olis-clarity/data
	echo "making dir: $SDA1MOUNT/olis-clarity/data"
fi

if [ -d "$1" ]; then
	echo "calling rsync"
	rsync -av $1 $SDA1MOUNT/olis-clarity/data
	#rsync -av /var/www/html/data/ /media/usb0/olis-clarity/data

# make sure data finished writing to device
	echo "calling sync"
	sync
fi

