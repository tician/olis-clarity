#!/bin/bash

sudo apt-get -y update
sudo apt-get -y install olis-clarity
echo "reboot"
sudo reboot

exit 0